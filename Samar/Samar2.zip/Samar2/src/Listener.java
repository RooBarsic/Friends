import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;

public class Listener extends Thread {
    private int localPort;
    private String remoteHost;
    private int remotePort;

    Listener(int localPort, String remoteHost, int remotePort){
        this.localPort = localPort;
        this.remoteHost = remoteHost;
        this.remotePort = remotePort;
    }

    @Override
    public void run() {
        try {
            System.out.println(" Server addres : " + Inet4Address.getLocalHost().getHostAddress());
            DatagramSocket datagramSocket = new DatagramSocket(localPort);
            while(true){
                byte[] responseBytes = new byte[1000];
                DatagramPacket datagramPacket = new DatagramPacket(responseBytes, 1000);
                datagramSocket.receive(datagramPacket);
                new Speaker(remoteHost, remotePort, datagramSocket, datagramPacket).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
