import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class Speaker extends Thread{
    private String remoteHost;
    private int remotePort;
    private DatagramPacket datagramPacket;
    private DatagramSocket datagramSocket;

    Speaker(String remoteHost, int remotePort, DatagramSocket datagramSocket, DatagramPacket packet){
        this.remoteHost = remoteHost;
        this.remotePort = remotePort;
        this.datagramSocket = datagramSocket;
        datagramPacket = packet;
    }

    public void run(){
        try {
            datagramPacket.setAddress(InetAddress.getByName(remoteHost));
            datagramPacket.setPort(remotePort);
            datagramSocket.send(datagramPacket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
