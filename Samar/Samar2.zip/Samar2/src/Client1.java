import java.io.*;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.Scanner;

public class Client1 {
    public static void main(String[] args) {
        try {
            System.out.println(" Start sending mesages ......");
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.print(" Write message : ");
                String message = scanner.nextLine();

                // send data to port 5801
                InetSocketAddress serverAddress = new InetSocketAddress("localhost", 5801);
                DatagramChannel channel = DatagramChannel.open();
                channel.bind(null);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(baos);
                oos.writeObject(message);
                oos.flush();

                byte[] messageBytes = baos.toByteArray();
                ByteBuffer messageBuffer = ByteBuffer.wrap(messageBytes);
                channel.send(messageBuffer, serverAddress);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
