import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.util.Arrays;

public class Client2 {
    public static void main(String[] args) {
        try {
            System.out.println(" Start listening ..... ");
            // listen port 1101
            DatagramSocket datagramSocket = new DatagramSocket(1101);
            while(true){
                byte[] responseBytes = new byte[1000];
                DatagramPacket datagramPacket = new DatagramPacket(responseBytes, 1000);
                datagramSocket.receive(datagramPacket);

                try {
                    ByteArrayInputStream bais = new ByteArrayInputStream(datagramPacket.getData());
                    ObjectInputStream ois = new ObjectInputStream(bais);
                    String resivedMessage = (String) ois.readObject();

                    System.out.println("got message : " + resivedMessage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
