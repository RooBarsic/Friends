
import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 1) {
            System.err.println("Wrong argument type. Please check initialization arguments");
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(new File(args[0])))) {
            while (br.ready()) {
                String[] st = br.readLine().split(" ");
                new Listener(Integer.parseInt(st[0]), st[1], Integer.parseInt(st[2])).start();
            }
        } catch (NumberFormatException e) {
            System.err.println("Wrong argument type");
            return;
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
            return;
        } catch (IOException e) {
            System.err.println("IOException");
            return;
        }
    }
}
